import { createContext } from "react";

const MicroContext = createContext(null);

export default MicroContext;
